## 登录函数
fun_login(){
    case $1 in
        192.168.0.222) fun_login1 $1 ;;
        *) fun_login2 $1 ;;
    esac
}

fun_login1(){
	ip=$1
	ssh ${ip} -p 22 -P ligengxin112233445566
}

fun_login2(){
	ip=$1
	ssh root@${ip} -p 22 -i ./zhengsiying
}

## 命令行帮助
fun_help(){
    echo "============================================="
    echo "请输入一个ip地址："
    echo "---------------------------------------------"
    echo "本地服：192.168.0.222"
    echo "外网测试服：118.89.151.81"
    echo "高配服：123.206.203.28"
    echo "web服：123.206.225.144"
    echo "============================================="
}

if [ $# -eq 0 ]; then
    fun_help
else
    fun_login $1
fi


