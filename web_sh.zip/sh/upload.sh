#!/usr/bin/env bash

source `dirname $0`/header.sh

fun_upload(){
    ver=$1
    FineName="ebin_${ver}.zip"
    BinFile="${BRANCH_PATH}/${FineName}"
    if [ -f ${BinFile} ]; then
        cd ${SCRIPT_PATH}
        ssh -i ./zhengsiying root@118.89.151.81 "cd ${WEB_BRANCH_PATH}; rm -rf ${FineName};"
        echo "开始上传"
        scp -i ./zhengsiying ${BinFile} root@118.89.151.81:${WEB_BRANCH_PATH}/${FineName}
        echo "版本：${ver} 上传完成"
    else
        echo "版本：${ver} 还没打包，请先执行打包指令pack.sh"
    fi
}

## 命令行帮助
fun_help(){
    echo "============================================="
    echo "请输入一个版本号："
    echo "---------------------------------------------"
    echo "版本号前3位表示大版本，后4位表示小版本，不足位用0占位"
    echo "版本号格式如0010000：表示大版本1，小版本号0"
    echo "============================================="
}

if [ $# -eq 0 ]; then
    fun_help
    echo -n "Enter: "
    read -a Ver
    echo "ver is : ${Ver[0]}"
    fun_upload ${Ver[0]}
else
    fun_upload $1
fi

