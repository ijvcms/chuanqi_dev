#!/usr/bin/env bash

source `dirname $0`/header.sh

fun_update_test(){
    ver=$1
    FineName="ebin_${ver}.zip"
    BinFile="${WEB_BRANCH_PATH}/${FineName}"
    if [ -f ${BinFile} ]; then
        cd ${SERVER_TEST_PATH}
        echo "关闭服务器"
        sh/stop_all.sh
        echo "删除旧的ebin文件"
        rm -rf ebin/
        echo "解压版本包"
        unzip ${BinFile}
        echo "开启服务器"
        sh/start_all.sh
        echo "版本：${ver} 更新完成"
    else
        echo "版本：${ver} 还没上传，请先打包上传"
    fi
}

fun_update_all(){
    ver=$1
    echo "------------------------------------"
    echo "更新测试服"
    fun_update_test ${ver}
    echo "------------------------------------"
    echo "更新正式服"
}

fun_main(){
    case $1 in
        test) fun_update_test $2 ;;
        all) fun_update_all $2 ;;
        *) echo "命令错误" ;;
    esac
}

fun_main $1 $2