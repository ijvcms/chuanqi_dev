#!/usr/bin/env bash

## 迁服
fun_move(){
    OutIp=$1
    OutDir=$2
    ServerId=$3
    InIp=$4
    echo "登录迁出服执行打包指令"
    ssh -i ./zhengsiying root@118.89.151.81 "cd ${WEB_BRANCH_PATH}; ./do_move1.sh ${OutDir} ${ServerId} ${InIp};"
}

}
## 命令行帮助
fun_help(){
    echo "==========================================================="
    echo "请输入 迁出服务器ip地址 服务器文件夹名 服务器id 迁入服务器ip地址："
    echo "==========================================================="
}

if [ $# -eq 0 ]; then
    fun_help
    echo -n "Enter: "
    read -a Cmd
    echo "Cmd is : ${Cmd[0]}"
    fun_update ${Cmd[0]} ${Cmd[1]}
else
    fun_update $1 $2
fi
