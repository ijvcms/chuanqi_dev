#!/usr/bin/env bash

## 迁服打包数据库和代码文件
OutDir=$2
ServerId=$3
InIp=$4
cd ../${OutDir}
echo "导出数据库"
mysqldump -u${MYSQL_USER} -p${MYSQL_PASS} chuanqi_db_${ServerId} > chuanqi_db_${ServerId}.sql
echo "导出游戏数据库成功"
mysqldump -u${MYSQL_USER} -p${MYSQL_PASS} chuanqi_log_${ServerId} > chuanqi_log_${ServerId}.sql
echo "导出日志数据库成功"

cd ../
zip -q -r
