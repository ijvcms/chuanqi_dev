#!/usr/bin/env bash

source `dirname $0`/header.sh

fun_update(){
    cd ${SCRIPT_PATH}
    flag=$1
    ver=$2
    ssh -i ./zhengsiying root@118.89.151.81 "cd ${WEB_SCRIPT_PATH}; ./do_update.sh ${flag} ${ver};"
}

## 命令行帮助
fun_help(){
    echo "============================================="
    echo "请输入更新方式和版本号："
    echo "---------------------------------------------"
    echo "1.更新方式："
    echo "  test: 只更新测试服"
    echo "  all: 更新所有服"
    echo "2.版本号："
    echo "  版本号前3位表示大版本，后4位表示小版本，不足位用0占位"
    echo "  版本号格式如0010000：表示大版本1，小版本号0"
    echo "============================================="
}

if [ $# -eq 0 ]; then
    fun_help
    echo -n "Enter: "
    read -a Cmd
    echo "Cmd is : ${Cmd[0]}"
    fun_update ${Cmd[0]} ${Cmd[1]}
else
    fun_update $1 $2
fi