#!/usr/bin/env bash
# 头文件
# @author: zhengsiying
# @date: 2015.04.09
#

SCRIPT_PATH="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )" # 运行脚本目录
cd ${SCRIPT_PATH}
cd ../
PROJECT_PATH=`pwd` # ERL服务端安装目录
SERVER_PATH="${PROJECT_PATH}/server"
BRANCH_PATH="${PROJECT_PATH}/branch"
WEB_BRANCH_PATH="/data/branch"
WEB_SCRIPT_PATH="/data/sh"
SERVER_TEST_PATH="/data/cqmmo_test_1"
MYSQL_USER="root"
MYSQL_PASS="eDc3168A51dF"