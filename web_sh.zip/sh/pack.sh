#!/usr/bin/env bash

source `dirname $0`/header.sh

## 打包函数
fun_pack(){
    ver=$1
    binFile="${BRANCH_PATH}/ebin_${ver}.zip"
    if [ ! -f ${binFile} ]; then
        echo "开始打包代码"
        cd ${SERVER_PATH}
        zip -q -r ${binFile} ./ebin
        echo "版本：${ver} 打包完成"
    else
        echo "版本：${ver} 已经存在，请先删除"
    fi
}

## 命令行帮助
fun_help(){
    echo "============================================="
    echo "请输入一个版本号："
    echo "---------------------------------------------"
    echo "版本号前3位表示大版本，后4位表示小版本，不足位用0占位"
    echo "版本号格式如0010000：表示大版本1，小版本号0"
    echo "============================================="
}

if [ $# -eq 0 ]; then
    fun_help
    echo -n "Enter: "
    read -a Ver
    echo "ver is : ${Ver[0]}"
    fun_pack ${Ver[0]}
else
    fun_pack $1
fi